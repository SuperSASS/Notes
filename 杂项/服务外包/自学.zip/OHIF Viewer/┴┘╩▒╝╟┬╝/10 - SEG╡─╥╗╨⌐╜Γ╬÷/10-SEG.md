# SEG解析

## 概念

* segmentation
* segment

## 对于SEG的displaySet的重要属性

* segments - 存储的是所有的？

## SegmentationService

在`createSegmentationForSEGDisplaySet()`函数中，是有关创建SEG的displaySet的函数。  
参数为在segSopClassHandler中解析得到的，有关该SEG的displaySet